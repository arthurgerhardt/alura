import Cocoa

var idade = 38

if idade >= 18 {
    print("Pode iniciar o processo de tirar a CNH.")
}
else {
    print("Você ainda não pode tirar a CNH.")
}

var possuiCNHValida = true

if idade >= 18 && possuiCNHValida {
    print("Você está apto a dirigir.")
}
else {
    print("Você não está apto a dirigir.")
}
