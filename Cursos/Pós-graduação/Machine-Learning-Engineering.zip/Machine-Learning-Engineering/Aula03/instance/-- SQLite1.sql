-- SQLite
-- SQLite
CREATE TABLE "user" (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO "user" (name, email, password) VALUES
('Arthur', 'arthur@email.com', 'senha123'),
('Maria', 'maria@email.com', 'senha456'),
('João', 'joao@email.com', 'senha789');